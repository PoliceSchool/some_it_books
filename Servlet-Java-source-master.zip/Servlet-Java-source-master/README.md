# Servlet-Java-source
servlet Java源码带中文注释，中文注释是根据《Servlet3.1规范》标注，用于学习servlet源码

##
#ScreenShot

<div align=center><img width="500" height="500" src="https://github.com/lintianlin/Servlet-Java-source/blob/master/pic01.png"/></div>
