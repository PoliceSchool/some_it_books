package javax.servlet.descriptor;

public interface TaglibDescriptor {
    String getTaglibURI();

    String getTaglibLocation();
}
