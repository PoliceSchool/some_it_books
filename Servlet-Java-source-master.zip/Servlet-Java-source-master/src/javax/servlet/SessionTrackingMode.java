package javax.servlet;

public enum SessionTrackingMode {
    COOKIE,
    URL,
    SSL;

    private SessionTrackingMode() {
    }
}
